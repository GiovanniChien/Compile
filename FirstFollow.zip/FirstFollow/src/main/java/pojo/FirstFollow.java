package pojo;

import java.util.Set;

/**
 * First集和Follow集
 */
public class FirstFollow {

    public String s;
    public Set<Character> first;//s的first集
    public Set<Character> follow;//s的follow集

}
