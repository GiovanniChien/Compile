package pojo;

import java.util.List;

public class FAT {

    public List<String> VNs;//非终结符，行
    public List<Character> VTs;//终结符，列
    public String[][] table;

}
